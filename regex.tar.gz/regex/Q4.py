
import re
s=["img0912.jpg","updated_img0912.png","favicon.gif","img0912.jpg.tmp","workspace.doc",".bash_profile"]
i=0
while i<=5:
    reg=re.match('(.+?)\.(.*\.)?(jpg|jpeg|bmp|tiff|gif|png)$',s[i],re.I)
    if reg!=None :
        if reg.group(2):
            print("damn")
        else:
            print(reg.group(1),reg.group(3))
    else:
        print("damn")
    i=i+1

