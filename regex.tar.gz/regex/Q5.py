import re
s=["ftp://file_server.com:21/top_secret/life_changing_plans.pdf","https://regexone.com/lesson/introduction#section"]
i=0
while i<=1:
    reg=re.match('(.*?)://(.*?):?([0-9]*)/.*$',s[i],re.I)
    if reg!=None :
        print(reg.group(1),reg.group(2),reg.group(3))
    else:
        print("damn")
    i=i+1

