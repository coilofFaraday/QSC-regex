import re
s=["fE/( 1553):      at widget.List.makeView(ListView.java:1727)","E/( 1553):        at widget.List.fillDown(ListView.java:652)","E/( 1553):        at widget.List.fillFrom(ListView.java:709)","W/dalvikvm( 1553): threadid=1: uncaught exception"]
i=0
while i<=3:
    reg=re.match('.*?:(.*?)\((.*):(\d*)\)$',s[i],re.I)
    if reg!=None :
        reg1=re.match('.*\.(.*)',reg.group(1))
        if reg1!=None:
             print(reg1.group(1),reg.group(2),reg.group(3))
    else:
        print("damn")
    i=i+1

