
import re
s=['tom@hogwarts.com','tom.riddle@hogwarts.com','tom.riddle+regexone@hogwarts.com','tom@hogwarts.eu.com','potter@hogwarts.com','harry@hogwarts.com','hermione+regexone@hogwarts.com']
i=0
while i<=6 :
    reg=re.match('([a-z\.A-Z]+)(.*)@(.*?)\..*$',s[i])
    if reg!=None:
    	print(reg.group(1),reg.group(3))
    	i=i+1
    else:
    	print("damn")

