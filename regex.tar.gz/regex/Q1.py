
import re
s=['650-555-2345', '415-555-1234', '(416)555-3456', '202 555 4567', '4035555678', '1 416 555 9292']
i=0
while i<=5 :
    reg=re.match('.*([0-9]{3}).555.*$',s[i])
    if reg!=None:
    	print(reg.group(1))
    	i=i+1
    else:
    	print("damn")

