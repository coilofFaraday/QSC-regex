
import re
s=["<a>This is a link</a>","<a href='https://regexone.com'>Link</a>","<div class='test_style'>Test</div>","<div>Hello <span>world</span></div>"]
i=0
while i<=3 :
    reg=re.match('.*</(.*)>$',s[i])
    if reg!=None:
    	print(reg.group(1))
    	i=i+1
    else:
    	print("damn")

